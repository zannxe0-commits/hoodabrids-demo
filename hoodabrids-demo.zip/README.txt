# Hoodabrids Pictures Demo

This is a mobile-first demo website.

Files:
- index.html
- images/photo-1.jpg
- images/photo-2.jpg
- images/photo-3.jpg

To publish from your phone:
1. Create a public GitHub repository.
2. Upload index.html and the images folder.
3. Import the GitHub repository into Vercel.
4. Deploy.
5. Send the resulting .vercel.app URL as the demo.

Before selling the final site, confirm the business approves the photos, wording, address, promotion, and contact details.
